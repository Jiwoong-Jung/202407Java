package mvjsp.chap17.board.service;

public class InvalidPasswordException extends Exception {

	public InvalidPasswordException(String message) {
		super(message);
	}
	
}
