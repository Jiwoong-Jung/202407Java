package mvjsp.chap17.board.service;

public class LastChildAleadyExistsException extends Exception {

	public LastChildAleadyExistsException(String message) {
		super(message);
	}

}
