package mvjsp.chap17.board.service;

public class CannotReplyArticleException extends Exception {

	public CannotReplyArticleException(String message) {
		super(message);
	}

}
